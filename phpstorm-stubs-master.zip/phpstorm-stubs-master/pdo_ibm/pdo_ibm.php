<?php

// Start of pdo_ibm v.1.2.3

function confirm_pdo_ibm_compiled () {}

// End of pdo_ibm v.1.2.3
?>
