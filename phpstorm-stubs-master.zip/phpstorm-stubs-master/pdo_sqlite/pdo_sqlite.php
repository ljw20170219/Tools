<?php

// Start of pdo_sqlite v.1.0.1
// End of pdo_sqlite v.1.0.1
?>
